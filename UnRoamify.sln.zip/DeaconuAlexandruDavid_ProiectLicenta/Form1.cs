﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Security.Principal;
using System.Security.AccessControl;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Security.Cryptography;
using System.Runtime.InteropServices;


namespace DeaconuAlexandruDavid_ProiectLicenta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        [DllImport("KERNEL32.DLL", EntryPoint = "RtlZeroMemory")]
        public static extern bool ZeroMemory(IntPtr Destination, int Length);

        // Creates a random salt that will be used to encrypt your file. This method is required on FileEncrypt.
        public static byte[] GenerateRandomSalt()
        {
            byte[] data = new byte[32];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                for (int i = 0; i < 10; i++)
                {
                    // Fille the buffer with the generated data
                    rng.GetBytes(data);
                }
            }

            return data;
        }



        // Encrypts a file from its path and a plain password.
        private void FileEncrypt(string inputFile, string password)
        {
            //generate random salt
            byte[] salt = GenerateRandomSalt();

            //create output file name
            FileStream fsCrypt = new FileStream(inputFile + ".aes", FileMode.Create);

            //convert password string to byte arrray
            byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);

            //Set Rijndael symmetric encryption algorithm
            RijndaelManaged AES = new RijndaelManaged();
            AES.KeySize = 256;
            AES.BlockSize = 128;
            AES.Padding = PaddingMode.PKCS7;


            //"What it does is repeatedly hash the user password along with the salt." High iteration counts.
            var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
            AES.Key = key.GetBytes(AES.KeySize / 8);
            AES.IV = key.GetBytes(AES.BlockSize / 8);

            AES.Mode = CipherMode.CFB;

            // write salt to the begining of the output file, so in this case can be random every time
            fsCrypt.Write(salt, 0, salt.Length);

            CryptoStream cs = new CryptoStream(fsCrypt, AES.CreateEncryptor(), CryptoStreamMode.Write);

            FileStream fsIn = new FileStream(inputFile, FileMode.Open);

            //create a buffer (1mb) so only this amount will allocate in the memory and not the whole file
            byte[] buffer = new byte[1048576];
            int read;

            try
            {
                while ((read = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                {
                    Application.DoEvents(); // -> for responsive GUI, using Task will be better!
                    cs.Write(buffer, 0, read);
                }

                // Close up
                fsIn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                cs.Close();
                fsCrypt.Close();
            }
        }



        // Decrypts an encrypted file with the FileEncrypt method through its path and the plain password.
        private void FileDecrypt(string inputFile, string outputFile, string password)
        {
            byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
            byte[] salt = new byte[32];

            FileStream fsCrypt = new FileStream(inputFile, FileMode.Open);
            fsCrypt.Read(salt, 0, salt.Length);

            RijndaelManaged AES = new RijndaelManaged();
            AES.KeySize = 256;
            AES.BlockSize = 128;
            var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
            AES.Key = key.GetBytes(AES.KeySize / 8);
            AES.IV = key.GetBytes(AES.BlockSize / 8);
            AES.Padding = PaddingMode.PKCS7;
            AES.Mode = CipherMode.CFB;

            CryptoStream cs = new CryptoStream(fsCrypt, AES.CreateDecryptor(), CryptoStreamMode.Read);

            FileStream fsOut = new FileStream(outputFile, FileMode.Create);

            int read;
            byte[] buffer = new byte[1048576];

            try
            {
                while ((read = cs.Read(buffer, 0, buffer.Length)) > 0)
                {
                    Application.DoEvents();
                    fsOut.Write(buffer, 0, read);
                }
            }
            catch (CryptographicException ex_CryptographicException)
            {
                Console.WriteLine("CryptographicException error: " + ex_CryptographicException.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            try
            {
                cs.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error by closing CryptoStream: " + ex.Message);
            }
            finally
            {
                fsOut.Close();
                fsCrypt.Close();
            }
        }

        public static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal userRunningApp = new WindowsPrincipal(identity);
            return userRunningApp.IsInRole(WindowsBuiltInRole.Administrator);
        }

        public string text, configfile = Directory.GetCurrentDirectory() + @"\config.ini", discression = Directory.GetCurrentDirectory() + @"\discression";

        private void ReadConfig(string conf)
        {
            if (File.Exists(conf))
            {
                string[] config = File.ReadAllLines(conf);
                if (config.Count() == 12)
                {
                    if (File.Exists(config[1]) && Directory.Exists(config[2]) && File.Exists(config[3]))
                    {
                        txbxLog.Text = config[1];
                        txbxRoamLoc.Text = config[2];
                        txbxDelProf.Text = config[3];
                        txbxProfilesInput.Text = File.ReadAllText(txbxDelProf.Text);
                        txbxADAdmin.Text = config[4];
                        txbxDomain1.Text = config[5];
                        if (config[6]=="Sort alphabetically = true")
                        {
                            radBtnAlphaSort.Checked = true;
                        }
                        else
                        {
                            radBtnDontSort.Checked = true;
                        }
                        if (config[7]=="Delete by User")
                        {
                            radBtnDelByUser.Checked = true;
                        }
                        else
                        {
                            radBtnDelByProfile.Checked = true;
                        }
                        if(config[8]=="Legacy = checked")
                        {
                            chkbxXP.Checked = true;
                        }
                        else
                        {
                            chkbxXP.Checked = false;
                        }
                        if(config[9]=="V2 = checked")
                        {
                            chkbxV2.Checked = true;
                        }
                        else
                        {
                            chkbxV2.Checked = false;
                        }
                        if (config[10] == "V5 = checked")
                        {
                            chkbxV5.Checked = true;
                        }
                        else
                        {
                            chkbxV5.Checked = false;
                        }
                        if (config[11] == "V6 = checked")
                        {
                            chkbxV6.Checked = true;
                        }
                        else
                        {
                            chkbxV6.Checked = false;
                        }

                    }
                    else
                    {
                        MessageBox.Show("One of the files / folders in the config has been changed or deleted. Skipping config...", "AAAAAAA!!!1!!11!!!!");
                    }
                }
                else
                {
                    MessageBox.Show("Config is corrupt", "Booo...");
                }
            }
        }

        private void WriteFile(string conf)
        {
            bool ok = false;
            if (string.IsNullOrWhiteSpace(txbxLog.Text))
            {
                DialogResult answer = MessageBox.Show("There is no log file set. Are you sure you never want a log file?", "Uh. Ah. Uhmm...", MessageBoxButtons.YesNo);
                if (answer == DialogResult.Yes)
                {
                    ok = true;
                }
            }
            if (!string.IsNullOrWhiteSpace(txbxRoamLoc.Text) && !string.IsNullOrWhiteSpace(txbxDelProf.Text))
            {
                // Check if there is a log file selected and either add it to config or add white space to config
                if (ok)
                {
                    File.WriteAllText(conf, "Do not modify this file yourself. Modifying this might cause the config to stop working correctly which MIGHT RESULT IN DATA LOSS ! Also, do not attempt to create a config file manually. You might get it wrong and you are doing it at your own risk." + Environment.NewLine + Environment.NewLine + txbxRoamLoc.Text + Environment.NewLine + txbxDelProf.Text + Environment.NewLine + txbxADAdmin.Text + Environment.NewLine + txbxDomain1.Text + Environment.NewLine);
                }
                else
                {
                    File.WriteAllText(conf, "Do not modify this file yourself. Modifying this might cause the config to stop working correctly which MIGHT RESULT IN DATA LOSS ! Also, do not attempt to create a config file manually. You might get it wrong and you are doing it at your own risk." + Environment.NewLine + txbxLog.Text + Environment.NewLine + txbxRoamLoc.Text + Environment.NewLine + txbxDelProf.Text + Environment.NewLine + txbxADAdmin.Text + Environment.NewLine + txbxDomain1.Text + Environment.NewLine);
                }

                // Add the selected sort option into the config
                if (radBtnAlphaSort.Checked == true)
                {
                    File.AppendAllText(conf, "Sort alphabetically = true" + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(conf, "Sort alphabetically = false" + Environment.NewLine);
                }

                // Add the preferred method of deletion into the config
                if (radBtnDelByUser.Checked == true)
                {
                    File.AppendAllText(conf, "Delete by User" + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(conf, "Delete by Profile" + Environment.NewLine);
                }

                // Add the checked profiles to be deleted checkboxes to the config
                if (chkbxXP.Checked == true)
                {
                    File.AppendAllText(conf, "Legacy = checked" + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(conf, "Legacy = unchecked" + Environment.NewLine);
                }
                if (chkbxV2.Checked == true)
                {
                    File.AppendAllText(conf, "V2 = checked" + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(conf, "V2 = unchecked" + Environment.NewLine);
                }
                if (chkbxV5.Checked == true)
                {
                    File.AppendAllText(conf, "V5 = checked" + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(conf, "V5 = unchecked" + Environment.NewLine);
                }
                if (chkbxV6.Checked == true)
                {
                    File.AppendAllText(conf, "V6 = checked");
                }
                else
                {
                    File.AppendAllText(conf, "V6 = unchecked");
                }

                if (!string.IsNullOrEmpty(txbxADAdminPasswd.Text))
                {
                    if (File.Exists(discression + @".aes"))
                    {
                        File.SetAttributes(discression + @".aes", FileAttributes.Normal);
                        File.Delete(discression + @".aes");
                    }
                    File.Create(discression).Close();
                    File.WriteAllText(discression, txbxADAdminPasswd.Text);
                    string password = "uS<Hx;.MoMUCmExt#[eeZi]X=ip|J8";
                    // For additional security, pin the password
                    GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);

                    // Encrypt the file
                    FileEncrypt(discression, password);
                    // To increase the security of the encryption, delete the given password from the memory
                    ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
                    gch.Free();
                    File.Delete(discression);
                    File.SetAttributes(discression + @".aes", FileAttributes.ReadOnly);
                }
                else
                {
                    if (File.Exists(discression + @".aes"))
                    {
                        File.SetAttributes(discression + @".aes", FileAttributes.Normal);
                        File.Delete(discression + @".aes");
                    }
                }

            }
            else
            {
                MessageBox.Show("Please select the Roaming Location Path and Profiles to be deleted path.", "Do you really want an empty config?");
            }
        }

        private void CheckConfigFileExist(string conf)
        {
            if (File.Exists(conf))
            {
                DialogResult answer = MessageBox.Show("A config file already exist. Do you want to replace it with your current settings?", "Aaaarrgh!!!", MessageBoxButtons.YesNo);
                if (answer == DialogResult.Yes)
                {
                    WriteFile(conf);
                }
            }
            else
            {
                WriteFile(conf);
            }
        }

        private void CheckConfigFolderExist(string conf)
        {
            //The function for writing the configuration is made in 3 steps. The first one is CheckConfigFolderExist, followed by CheckConfigFileExist and then by WriteFile - I AM SORRY FOR MY NAMING SCHEMES, I'M AN AUTIST, THANKS FOR POINTING THAT OUT
            //CheckConfigFolderExist only checks if the directory of the configuration file exists, so I don't have to copy-paste the same code over and over again for ~4 times
            /*Explaining the above point:
                if directory exist
                    if file exist
                        ask if you want to replace
                        if yes
                            delete
                            if no log file selected
                                ask if you don't want a log file
                                if yes (you don't want)
                                    create file
                    else
                        if no log file selected
                            ask if you don't want a log file
                            if yes (you don't want)
                                create file
                else
                    create directory
                    if file exist
                        ask if you want to replace
                        if yes
                            delete
                            if no log file selected
                                ask if you don't want a log file
                                if yes (you don't want)
                                    create file
                    else
                        if no log file selected
                            ask if you don't want a log file
                            if yes (you don't want)
                                create file
             */
            if (Directory.Exists(Path.GetDirectoryName(conf)))
            {
                CheckConfigFileExist(conf);
            }
            else
            {
                Directory.CreateDirectory(Path.GetDirectoryName(conf));
                CheckConfigFileExist(conf);
            }
        }

        private bool CheckADBoxesNotEmpty()
        {
            if (string.IsNullOrWhiteSpace(txbxDomain1.Text))
            {
                MessageBox.Show("Please enter your AD domain name", "Another error");
                return false;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(txbxADAdmin.Text))
                {
                    MessageBox.Show("Please enter your AD account with rights to access the AD domain (query rights)", "Ooga Booga error");
                    return false;
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txbxADAdminPasswd.Text))
                    {
                        MessageBox.Show("Please enter your AD account password", "And your password is... what was it again?");
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
        }

        static void ReplaceAllSubdirNFilesPermissionsFromObject(DirectoryInfo dInfo, DirectorySecurity dSecurity)
        {            
            dInfo.SetAccessControl(dSecurity);                     // Copy the DirectorySecurity to the current directory

            foreach (FileInfo fi in dInfo.GetFiles())
            {
                var ac = fi.GetAccessControl();                   // Get the file's FileSecurity                
                ac.SetAccessRuleProtection(false, false);         // inherit from the directory                
                fi.SetAccessControl(ac);                          // apply change
            }
           
            dInfo.GetDirectories().ToList()                      // Recurse into Directories
                .ForEach(d => ReplaceAllSubdirNFilesPermissionsFromObject(d, dSecurity));
        }

        private string UserQuery(string userQueried)
        {

            DirectoryEntry searchRoot = new DirectoryEntry(@"LDAP://" + txbxDomain1.Text, txbxADAdmin.Text, txbxADAdminPasswd.Text);
            DirectorySearcher searchForUser = new DirectorySearcher(searchRoot);
            searchForUser.Filter = string.Format("(&(objectClass=user)(objectCategory=Person)(anr={0}))", userQueried);
            searchForUser.PropertiesToLoad.Add("samaccountname");

            if (searchForUser.FindOne() != null)
            {
                SearchResult mySearchResult = searchForUser.FindOne();
                DirectoryEntry users = mySearchResult.GetDirectoryEntry();
                if (Convert.ToString(users.Properties["samaccountname"][0]) == (userQueried))
                {
                    return "none";
                }
                else
                    return userQueried;
            }
            return userQueried;
        }

        private void ProfileQueryAll()
        {
            //Query AD for all users that have a profile path and add the paths to listBxProfiles, which will be used as an exception list ::== delete all profiles except these
            listBxProfiles.Items.Clear();
            DirectoryEntry searchRoot = new DirectoryEntry("LDAP://" + txbxDomain1.Text, txbxADAdmin.Text, txbxADAdminPasswd.Text);
            DirectorySearcher searchForUser = new DirectorySearcher(searchRoot);
            searchForUser.Filter = string.Format("(&(objectClass=user)(objectCategory=Person))");
            searchForUser.PropertiesToLoad.Add("samaccountname");
            searchForUser.PropertiesToLoad.Add("profilepath");
            
            SearchResult xSearchResult;
            SearchResultCollection xSearchResultCol = searchForUser.FindAll();
            if (xSearchResultCol != null)
            {
                for (int indexCol = 0; indexCol < xSearchResultCol.Count; indexCol++)
                {
                    xSearchResult = xSearchResultCol[indexCol];
                    if (xSearchResult.Properties.Contains("samaccountname") && xSearchResult.Properties.Contains("profilepath"))
                    {
                        string[] profpath = xSearchResult.Properties["profilepath"][0].ToString().Split('\\');
                        listBxProfiles.Items.Add(profpath[profpath.Count() - 1]);
                    }
                }
            }
        }

        private bool AreYouSure(string x)
        {
            DialogResult answer = MessageBox.Show("Are you sure you want to delete all " + x + " profiles?", "Careful now...", MessageBoxButtons.YesNo);
            if (answer == DialogResult.Yes)
            {
                DialogResult answer2 = MessageBox.Show("Are you really really sure you want to delete all " + x + " profiles? You can't go back on it, every " + x + " profile will be deleted", "Last chance to change your mind", MessageBoxButtons.YesNo);
                if (answer2 == DialogResult.Yes)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        private string[] GetLocalFolders()
        {

            string[] roamingfoldersraw = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly), roamingfoldersedited = new string[10000];
            int countraw, countroam = 0;
            for (countraw = 0; countraw < roamingfoldersraw.Length; countraw++)
            {
                int ok = 0;
                if (roamingfoldersraw[countraw].EndsWith(".V2"))
                {
                    ok = 2;
                }
                if (roamingfoldersraw[countraw].EndsWith(".V5"))
                {
                    ok = 5;
                }
                if (roamingfoldersraw[countraw].EndsWith(".V6"))
                {
                    ok = 6;
                }
                switch (ok)
                {
                    case 2:
                        {
                            roamingfoldersedited[countroam] = roamingfoldersraw[countraw].Replace(".V2", "");
                            countroam++;
                            break;
                        }
                    case 5:
                        {
                            roamingfoldersedited[countroam] = roamingfoldersraw[countraw].Replace(".V5", "");
                            countroam++;
                            break;
                        }
                    case 6:
                        {
                            roamingfoldersedited[countroam] = roamingfoldersraw[countraw].Replace(".V6", "");
                            countroam++;
                            break;
                        }
                    default:
                        {
                            roamingfoldersedited[countroam] = roamingfoldersraw[countraw];
                            countroam++;
                            break;
                        }
                }
            }
            return roamingfoldersedited.Distinct().ToArray();
        }

        private void DeleteRoaming(string ItemToDelete)
        {
            if (!string.IsNullOrWhiteSpace(txbxRoamLoc.Text) && !string.IsNullOrWhiteSpace(ItemToDelete) && Directory.Exists(txbxRoamLoc.Text + @"\" + ItemToDelete))
            {
                IdentityReference owner = new NTAccount(txbxUser.Text);
                //get the name of the owner, in this case the Local Administrator which you should run this program with
                DirectoryInfo directory = new DirectoryInfo(txbxRoamLoc.Text + @"\" + ItemToDelete);
                //get the roaming profile folder you want to delete
                DirectorySecurity directorySecurity = directory.GetAccessControl();
                //get the current Access Control settings...
                directorySecurity.SetOwner(owner);
                directory.SetAccessControl(directorySecurity);
                ReplaceAllSubdirNFilesPermissionsFromObject(directory, directorySecurity);
                //...and give them to the Local Administrator
                if (!string.IsNullOrWhiteSpace(txbxLog.Text))
                    File.AppendAllText(txbxLog.Text, Environment.NewLine + Convert.ToString(owner) + " has taken access control of " + txbxRoamLoc.Text + @"\" + ItemToDelete + " at " + DateTime.Now.ToString("HH:mm:ss") + " " + DateTime.Today.ToString("dd-MM-yyyy"));
                //add to log

                Directory.Delete(txbxRoamLoc.Text + @"\" + ItemToDelete, recursive: true);
                //delete the roaming profile folder
                if (!string.IsNullOrWhiteSpace(txbxLog.Text))
                    File.AppendAllText(txbxLog.Text, Environment.NewLine + txbxRoamLoc.Text + @"\" + ItemToDelete + " has been deleted at " + DateTime.Now.ToString("HH:mm:ss") + " " + DateTime.Today.ToString("dd-MM-yyyy"));
                //add to log
            }          
        }

        private void btnSelectRoamingLocation_Click(object sender, EventArgs e)
        {
            //this button selects the folder location where the roaming profiles are located ($profiles)
            FolderBrowserDialog roamloc = new FolderBrowserDialog();
            DialogResult result = roamloc.ShowDialog();
            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(roamloc.SelectedPath))
            {
                txbxRoamLoc.Text = roamloc.SelectedPath;
                //the textbox near the button receives the path of the roaming profiles you chose
            }
        }

        private void btnLogLoc_Click(object sender, EventArgs e)
        {
            //this button selects the output file where the program will log the deleted profiles
            OpenFileDialog logloc = new OpenFileDialog();
            logloc.Title = "Browse Log Files";
            logloc.Filter = "log files (*.log)|*.log|txt files (*.txt)|*.txt|All files (*.*)|*.*";
            logloc.FilterIndex = 1;
            logloc.CheckFileExists = true;
            logloc.CheckPathExists = true;

            DialogResult result = logloc.ShowDialog();
            if (result == DialogResult.OK)
            {
                txbxLog.Text = logloc.FileName;
                //this textbox near the button receives the path of the log file you chose
            }
        }
        
        private void btnDelProf_Click(object sender, EventArgs e)
        {
            //this button selects the input file which contains the names of the users whose profiles will be deleted
            OpenFileDialog logloc = new OpenFileDialog();
            logloc.Title = "Browse Log Files";
            logloc.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            logloc.FilterIndex = 1;
            logloc.CheckFileExists = true;
            logloc.CheckPathExists = true;

            DialogResult result = logloc.ShowDialog();
            if (result == DialogResult.OK)
            {
                txbxDelProf.Text = logloc.FileName;
                //this textbox near the button receives the path of the input file you chose
                text = File.ReadAllText(logloc.FileName);
                txbxProfilesInput.Text = text;
                //this textbox will be a mirror of the input file you chose. You can edit it and save it inside the input file, using the btnSavProf button, named "Write script for deleting profiles"
            }
        }

        private void btnSavProf_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txbxDelProf.Text))
            {
                if (File.Exists(txbxDelProf.Text))
                {
                    this.Enabled = false;
                    File.WriteAllText(txbxDelProf.Text, txbxProfilesInput.Text);
                    text = txbxProfilesInput.Text;
                    this.Enabled = true;
                }
                else
                {
                    MessageBox.Show("<" + txbxDelProf.Text + "> file does not exist. Please create a file with the user names which roaming profiles you want to delete, then select it in the program (Roaming Profiles Location button)", "Are you even trying?");
                }
            }
            else
            {
                MessageBox.Show("Please create a file containing the user names which roaming profiles you want to delete, then select it in the program (Roaming Profiles Path button)", "Try harder !");
            }
        }

        private void importConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //This menu item imports an .ini file and overwrites the one saved in the application's settings
            OpenFileDialog ImportConfigMenu = new OpenFileDialog();
            ImportConfigMenu.Title = "Import Config File";
            ImportConfigMenu.Filter = "ini files (*.ini)|*.ini|All files (*.*)|*.*";
            ImportConfigMenu.FilterIndex = 1;
            ImportConfigMenu.CheckFileExists = true;
            ImportConfigMenu.CheckPathExists = true;
            if (ImportConfigMenu.ShowDialog()==DialogResult.OK)
            {
                if(MessageBox.Show("You are about to delete your old config file. It is recommended that you export your config file first, before you import another config, if you want to keep your config. Do you want to continue with the import (this will delete the old config)?", "Insert warning here", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    File.WriteAllText(configfile, File.ReadAllText(ImportConfigMenu.FileName));
                    ReadConfig(configfile);
                }
            }
        }

        private void exportConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //This menu item exports the current saved .ini file of the application into the location of your choice
            SaveFileDialog ExportConfigMenu = new SaveFileDialog();
            ExportConfigMenu.Title = "Export Config File";
            ExportConfigMenu.Filter = "ini files (*.ini)|*.ini|All files (*.*)|*.*";
            ExportConfigMenu.FilterIndex = 1;
            ExportConfigMenu.CheckPathExists = true;
            if (ExportConfigMenu.ShowDialog() == DialogResult.OK)
            {
                    WriteFile(ExportConfigMenu.FileName);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            //if I need to explain this to you, you shouldn't be looking through the source code - or you should learn more before doing so
        }

        private void saveConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CheckConfigFolderExist(configfile);
            //saves current configuration of the application. Next time you open the application, it will load these settings
        }

        private void openConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this menu opens a config file from a chosen location, but doesn't save it
            OpenFileDialog OpenConfigMenu = new OpenFileDialog();
            OpenConfigMenu.Title = "Browse Config File";
            OpenConfigMenu.Filter = "ini files (*.ini)|*.ini|All files (*.*)|*.*";
            OpenConfigMenu.FilterIndex = 1;
            OpenConfigMenu.CheckFileExists = true;
            OpenConfigMenu.CheckPathExists = true;

            DialogResult result = OpenConfigMenu.ShowDialog();
            if (result == DialogResult.OK)
            {
                ReadConfig(OpenConfigMenu.FileName);
            }
        }

        private void instructionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormInstructions fromInstructions = new FormInstructions();
            fromInstructions.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAbout formAbout = new FormAbout();
            formAbout.Show();
        }

        private void btnQueryAll_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            if((!string.IsNullOrWhiteSpace(txbxRoamLoc.Text)) && (!string.IsNullOrWhiteSpace(txbxDelProf.Text)))
            if(chkbxV2.Checked==false && chkbxV5.Checked==false && chkbxV6.Checked == false && chkbxXP.Checked==false)
            {
                MessageBox.Show("You don't have any roaming profiles selected. Please check the boxes of every roaming profile you want to delete.", "Check your privile... profiles");
            }
            btnSavProf_Click(sender, e);
            text = text.Replace("\r\n", ";");   //replace NewLine with ;
            text = text.Replace(" ", ";");      //replace Space with ;
            text = text.Replace(",", ";");      //replace , with ;

            string[] folders = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly);
            string[] texti = text.Split(';');   //breaking the userlist into separate entries
            listBxProfiles.Items.Clear();       //clears the list before making a new list
            if (radBtnAlphaSort.Checked)
            {
                listBxProfiles.Sorted = true;
            }
            else
            {
                listBxProfiles.Sorted = false;
            }
            //if radio button for sorting alphabetically is checked, it sorts the list alphabetically (duh...), otherwise, it will leave it just like the order in the file


            foreach (string profile in texti)
            {
                if (!string.IsNullOrWhiteSpace(profile))
                {
                    if (chkbxXP.Checked && Directory.Exists(txbxRoamLoc.Text + @"\" + profile))
                    {
                        listBxProfiles.Items.Add(profile);
                    }
                    if (chkbxV2.Checked && Directory.Exists(txbxRoamLoc.Text + @"\" + profile + @".V2"))
                    {
                        listBxProfiles.Items.Add(profile + @".V2");
                    }
                    if (chkbxV5.Checked && Directory.Exists(txbxRoamLoc.Text + @"\" + profile + @".V5"))
                    {
                        listBxProfiles.Items.Add(profile + @".V5");
                    }
                    if (chkbxV6.Checked && Directory.Exists(txbxRoamLoc.Text + @"\" + profile + @".V6"))
                    {
                        listBxProfiles.Items.Add(profile + @".V6");
                    }
                }
                //check if the "folder" is not an empty space, as it would sometimes get in as delete root / or "C:/$profiles/" altogether and you don't want to delete all roaming profiles, do you?
                //also, if the respective checkboxes are checked, this checks if there is a legacy roaming (XP), a V2, V5 and V6 profile and if it does, it is added to the list for deletion
            }
            this.Enabled = true;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            int currentdeleting, profilelistcount = listBxProfiles.Items.Count;
            //currentdeleting is the current user from the listbox that is being deleted | profilelistcount is the total ammount of users in the list
            if (IsAdministrator())
            {
                for (currentdeleting = 0; currentdeleting < profilelistcount; currentdeleting++)
                {
                        DeleteRoaming(Convert.ToString(listBxProfiles.Items[currentdeleting]));
                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw choosing your own customers");
            }
            this.Enabled = true;
        }

        private void radBtnAlphaSort_CheckedChanged(object sender, EventArgs e)
        {
            if (radBtnAlphaSort.Checked)
            {
                listBxProfiles.Sorted = true;
            }
            else
            {
                listBxProfiles.Sorted = false;
            }
        }

        private void deleteAllLegacyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsAdministrator())
            {
                if (AreYouSure("Legacy"))
                {
                    string[] roamingfolders = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly);
                    foreach (string profile in roamingfolders)
                    {
                        if ((profile.EndsWith(".V2")) || (profile.EndsWith(".V5")) || (profile.EndsWith(".V6")))
                        {
                        }
                        else
                        {
                            string[] editedprofile = profile.Split('\\');
                            DeleteRoaming(editedprofile[editedprofile.Length - 1]);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw you restrict unauthorised access");
            }
        }

        private void deleteAllV2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsAdministrator())
            {
                if (AreYouSure(".V2"))
                {
                    string[] roamingfolders = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly);
                    foreach (string profile in roamingfolders)
                    {
                        if (profile.EndsWith(".V2"))
                        {
                            string[] editedprofile = profile.Split('\\');
                            DeleteRoaming(editedprofile[editedprofile.Length - 1]);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw you restrict unauthorised access");
            }
        }

        private void deleteAllV5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsAdministrator())
            {
                if (AreYouSure(".V5"))
                {
                    string[] roamingfolders = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly);
                    foreach (string profile in roamingfolders)
                    {
                        if (profile.EndsWith(".V5"))
                        {
                            string[] editedprofile = profile.Split('\\');
                            DeleteRoaming(editedprofile[editedprofile.Length - 1]);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw you restrict unauthorised access");
            }
        }

        private void deleteAllV6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsAdministrator())
            {
                if (AreYouSure(".V6"))
                {
                    string[] roamingfolders = Directory.GetDirectories(txbxRoamLoc.Text, "*", SearchOption.TopDirectoryOnly);
                    foreach (string profile in roamingfolders)
                    {
                        if (profile.EndsWith(".V6"))
                        {
                            string[] editedprofile = profile.Split('\\');
                            DeleteRoaming(editedprofile[editedprofile.Length - 1]);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw you restrict unauthorised access");
            }
        }

        private void btnAutoDelete_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            if (IsAdministrator())
            {
                if (CheckADBoxesNotEmpty())
                {

                    if (chkbxV2.Checked == false && chkbxV5.Checked == false && chkbxV6.Checked == false && chkbxXP.Checked == false)
                    {
                        MessageBox.Show("Please check one or more profile versions to delete", "Bleep blop, I'm a bot");
                    }
                    else
                    {
                        if (radBtnDelByUser.Checked == true)
                        {
                            listBxProfiles.Items.Clear();
                            string[] roamingfolders = GetLocalFolders();
                            int pathlength = txbxRoamLoc.Text.Length + 1;

                            foreach (string i in roamingfolders)
                            {
                                if (!string.IsNullOrEmpty(i))
                                    if ((UserQuery(i.Remove(0, pathlength)) == "none" || UserQuery(i.Remove(0, pathlength)) == "Administrator" || UserQuery(i.Remove(0, pathlength)) == "Default" || UserQuery(i.Remove(0, pathlength)) == "Default.migrated"))
                                    { }
                                    else
                                    {
                                        listBxProfiles.Items.Add(UserQuery(i.Remove(0, pathlength)));
                                    }
                            }


                            foreach (string i in listBxProfiles.Items)
                            {
                                if (chkbxXP.Checked == true)
                                    DeleteRoaming(i);
                                if (chkbxV2.Checked == true)
                                    DeleteRoaming(i + ".V2");
                                if (chkbxV5.Checked == true)
                                    DeleteRoaming(i + ".V5");
                                if (chkbxV6.Checked == true)
                                    DeleteRoaming(i + ".V6");
                            }
                        }



                        if (radBtnDelByProfile.Checked == true)
                        {
                            ProfileQueryAll();
                            string[] roamingfolders = GetLocalFolders();
                            int pathlength = txbxRoamLoc.Text.Length + 1;

                            for (int i = 0; i < roamingfolders.Length - 1; i++)
                            {
                                if ((roamingfolders[i].Remove(0, pathlength)) != "none" && (roamingfolders[i].Remove(0, pathlength)) != "Administrator" && (roamingfolders[i].Remove(0, pathlength)) != "Default" && (roamingfolders[i].Remove(0, pathlength)) != "Default.migrated")
                                {
                                    roamingfolders[i] = roamingfolders[i].Remove(0, pathlength);
                                }
                            }

                            foreach (string i in roamingfolders)
                            {
                                bool ok = false;
                                //i is the local profile on the machine. j is the profile that is being used (querried in AD)
                                foreach (string j in listBxProfiles.Items)
                                {
                                    if (i == j)
                                    {
                                        ok = true;
                                        break;
                                    }
                                }

                                //If i== j (aka if i is being used), it doesn't do anything, else (if it's not in use), it gets deleted
                                if (!ok)
                                {
                                    if (chkbxXP.Checked == true)
                                        DeleteRoaming(i);
                                    if (chkbxV2.Checked == true)
                                        DeleteRoaming(i + ".V2");
                                    if (chkbxV5.Checked == true)
                                        DeleteRoaming(i + ".V5");
                                    if (chkbxV6.Checked == true)
                                        DeleteRoaming(i + ".V6");
                                }
                            }
                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("You're not administrator. Can't help you, sorry.", ">tfw you restrict unauthorised access");
            }
            this.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radBtnDelByProfile.Checked = true;
            radBtnDontSort.Checked = true;
            ReadConfig(configfile);
            if(!string.IsNullOrEmpty(txbxRoamLoc.Text))
                if (File.Exists(discression + @".aes"))
                {
                    File.SetAttributes(discression + @".aes", FileAttributes.Normal);
                    string password = "uS<Hx;.MoMUCmExt#[eeZi]X=ip|J8";
                    // Pin the password of your files, for later deletion
                    GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);

                    // Decrypt the file
                    FileDecrypt(discression + @".aes", discression, password);

                    // Read the password
                    txbxADAdminPasswd.Text = File.ReadAllText(discression);

                    // Deletes the given password from the memory
                    ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
                    gch.Free();
                    File.Delete(discression);
                    File.SetAttributes(discression + @".aes", FileAttributes.ReadOnly);
                }
            txbxUser.Text = Convert.ToString(WindowsIdentity.GetCurrent().Name); //Environment.MachineName + @"\" + Environment.UserName;
        }
    }
}
