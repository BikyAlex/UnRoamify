﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace DeaconuAlexandruDavid_ProiectLicenta
{
    public partial class FormInstructions : Form
    {
        public FormInstructions()
        {
            InitializeComponent();
        }

        public int i = 0;
        public string[] images = Directory.GetFiles(Directory.GetCurrentDirectory() + @"\Instructions");

        private void FormInstructions_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(Directory.GetCurrentDirectory() + @"\Instructions"))
            {
                picbxInstructions.Load(images[i]);
            }
            else
            {
                MessageBox.Show("Instructions Directory does not exist. Either you do not have the instructions, or this portion of code has not been modified to fit the new code");
            }
        }

        private void btnNextInstruc_Click(object sender, EventArgs e)
        {
            if(i+1 >= images.Count())
            {
                i = 0;
                picbxInstructions.Load(images[i]);
            }
            else
            {
                i++;
                picbxInstructions.Load(images[i]);
            }
        }

        private void btnBackInstruc_Click(object sender, EventArgs e)
        {
            if (i - 1 < 0)
            {
                i = images.Count() - 1;
                picbxInstructions.Load(images[i]);
            }
            else
            {
                i--;
                picbxInstructions.Load(images[i]);
            }
        }
    }
}
