﻿namespace DeaconuAlexandruDavid_ProiectLicenta
{
    partial class FormAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAbout));
            this.txbxAbout = new System.Windows.Forms.TextBox();
            this.btnCloseAbout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbxAbout
            // 
            this.txbxAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxAbout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txbxAbout.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxAbout.Location = new System.Drawing.Point(12, 12);
            this.txbxAbout.Multiline = true;
            this.txbxAbout.Name = "txbxAbout";
            this.txbxAbout.ReadOnly = true;
            this.txbxAbout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbxAbout.Size = new System.Drawing.Size(974, 620);
            this.txbxAbout.TabIndex = 1;
            this.txbxAbout.Text = resources.GetString("txbxAbout.Text");
            // 
            // btnCloseAbout
            // 
            this.btnCloseAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseAbout.Location = new System.Drawing.Point(889, 638);
            this.btnCloseAbout.Name = "btnCloseAbout";
            this.btnCloseAbout.Size = new System.Drawing.Size(97, 47);
            this.btnCloseAbout.TabIndex = 0;
            this.btnCloseAbout.Text = "Close";
            this.btnCloseAbout.UseVisualStyleBackColor = true;
            this.btnCloseAbout.Click += new System.EventHandler(this.btnCloseAbout_Click);
            // 
            // FormAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 697);
            this.Controls.Add(this.btnCloseAbout);
            this.Controls.Add(this.txbxAbout);
            this.Name = "FormAbout";
            this.Text = "About";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbxAbout;
        private System.Windows.Forms.Button btnCloseAbout;
    }
}