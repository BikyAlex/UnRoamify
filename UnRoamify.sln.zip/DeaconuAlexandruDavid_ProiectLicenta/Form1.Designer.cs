﻿namespace DeaconuAlexandruDavid_ProiectLicenta
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txbxRoamLoc = new System.Windows.Forms.TextBox();
            this.btnSelectRoamingLocation = new System.Windows.Forms.Button();
            this.txbxLog = new System.Windows.Forms.TextBox();
            this.btnLogLoc = new System.Windows.Forms.Button();
            this.btnDelProf = new System.Windows.Forms.Button();
            this.txbxDelProf = new System.Windows.Forms.TextBox();
            this.txbxProfilesInput = new System.Windows.Forms.TextBox();
            this.btnSavProf = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.chkbxXP = new System.Windows.Forms.CheckBox();
            this.chkbxV2 = new System.Windows.Forms.CheckBox();
            this.chkbxV5 = new System.Windows.Forms.CheckBox();
            this.chkbxV6 = new System.Windows.Forms.CheckBox();
            this.toolTip_btnSavProf = new System.Windows.Forms.ToolTip(this.components);
            this.btnQueryAll = new System.Windows.Forms.Button();
            this.listBxProfiles = new System.Windows.Forms.ListBox();
            this.radBtnAlphaSort = new System.Windows.Forms.RadioButton();
            this.radBtnDontSort = new System.Windows.Forms.RadioButton();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.specialDeletionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllLegacyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllV2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllV5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllV6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txbxUser = new System.Windows.Forms.TextBox();
            this.toolTip_btnLogLoc = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_btnSelectRoamingLocation = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_btnDelProf = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_btnQueryAll = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_btnStart = new System.Windows.Forms.ToolTip(this.components);
            this.btnAutoDelete = new System.Windows.Forms.Button();
            this.txbxADAdmin = new System.Windows.Forms.TextBox();
            this.txbxADAdminPasswd = new System.Windows.Forms.TextBox();
            this.txbxDomain1 = new System.Windows.Forms.TextBox();
            this.radBtnDelByProfile = new System.Windows.Forms.RadioButton();
            this.radBtnDelByUser = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txbxRoamLoc
            // 
            this.txbxRoamLoc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxRoamLoc.Location = new System.Drawing.Point(13, 201);
            this.txbxRoamLoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxRoamLoc.Name = "txbxRoamLoc";
            this.txbxRoamLoc.Size = new System.Drawing.Size(484, 28);
            this.txbxRoamLoc.TabIndex = 2;
            // 
            // btnSelectRoamingLocation
            // 
            this.btnSelectRoamingLocation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectRoamingLocation.Location = new System.Drawing.Point(503, 189);
            this.btnSelectRoamingLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSelectRoamingLocation.Name = "btnSelectRoamingLocation";
            this.btnSelectRoamingLocation.Size = new System.Drawing.Size(128, 50);
            this.btnSelectRoamingLocation.TabIndex = 3;
            this.btnSelectRoamingLocation.Text = "Roaming Profiles Path";
            this.toolTip_btnSelectRoamingLocation.SetToolTip(this.btnSelectRoamingLocation, "Select the location where the roaming profiles are currently save to (e.g. D:\\$pr" +
        "ofiles)");
            this.btnSelectRoamingLocation.UseVisualStyleBackColor = true;
            this.btnSelectRoamingLocation.Click += new System.EventHandler(this.btnSelectRoamingLocation_Click);
            // 
            // txbxLog
            // 
            this.txbxLog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxLog.Location = new System.Drawing.Point(13, 141);
            this.txbxLog.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txbxLog.Name = "txbxLog";
            this.txbxLog.Size = new System.Drawing.Size(484, 28);
            this.txbxLog.TabIndex = 0;
            // 
            // btnLogLoc
            // 
            this.btnLogLoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogLoc.Location = new System.Drawing.Point(503, 129);
            this.btnLogLoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLogLoc.Name = "btnLogLoc";
            this.btnLogLoc.Size = new System.Drawing.Size(128, 50);
            this.btnLogLoc.TabIndex = 1;
            this.btnLogLoc.Text = "Log File";
            this.toolTip_btnLogLoc.SetToolTip(this.btnLogLoc, "Select a log file where UnRoamify will log the changes it makes to the roaming pr" +
        "ofiles");
            this.btnLogLoc.UseVisualStyleBackColor = true;
            this.btnLogLoc.Click += new System.EventHandler(this.btnLogLoc_Click);
            // 
            // btnDelProf
            // 
            this.btnDelProf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelProf.Location = new System.Drawing.Point(503, 247);
            this.btnDelProf.Name = "btnDelProf";
            this.btnDelProf.Size = new System.Drawing.Size(128, 50);
            this.btnDelProf.TabIndex = 5;
            this.btnDelProf.Text = "Profiles to be deleted";
            this.toolTip_btnDelProf.SetToolTip(this.btnDelProf, "Select a file where you insert the names of the users that you want to delete the" +
        " roaming profiles from. This file will be opened and can be edited in the text b" +
        "ox below");
            this.btnDelProf.UseVisualStyleBackColor = true;
            this.btnDelProf.Click += new System.EventHandler(this.btnDelProf_Click);
            // 
            // txbxDelProf
            // 
            this.txbxDelProf.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxDelProf.Location = new System.Drawing.Point(12, 259);
            this.txbxDelProf.Name = "txbxDelProf";
            this.txbxDelProf.Size = new System.Drawing.Size(485, 28);
            this.txbxDelProf.TabIndex = 4;
            // 
            // txbxProfilesInput
            // 
            this.txbxProfilesInput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxProfilesInput.Location = new System.Drawing.Point(13, 303);
            this.txbxProfilesInput.Multiline = true;
            this.txbxProfilesInput.Name = "txbxProfilesInput";
            this.txbxProfilesInput.Size = new System.Drawing.Size(484, 284);
            this.txbxProfilesInput.TabIndex = 6;
            // 
            // btnSavProf
            // 
            this.btnSavProf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSavProf.Location = new System.Drawing.Point(503, 303);
            this.btnSavProf.Name = "btnSavProf";
            this.btnSavProf.Size = new System.Drawing.Size(128, 68);
            this.btnSavProf.TabIndex = 7;
            this.btnSavProf.Text = "Save Live Edit to \"Profiles to be Deleted\"";
            this.toolTip_btnSavProf.SetToolTip(this.btnSavProf, "Saves edit into the \"Profiles to be deleted\" file");
            this.btnSavProf.UseVisualStyleBackColor = true;
            this.btnSavProf.Click += new System.EventHandler(this.btnSavProf_Click);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(503, 451);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(128, 68);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "Start Manual Deleting";
            this.toolTip_btnStart.SetToolTip(this.btnStart, "Take ownership and control access of the folders, files and subfolders of the pro" +
        "files in the list box and then delete them");
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // chkbxXP
            // 
            this.chkbxXP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbxXP.AutoSize = true;
            this.chkbxXP.Location = new System.Drawing.Point(637, 153);
            this.chkbxXP.Name = "chkbxXP";
            this.chkbxXP.Size = new System.Drawing.Size(161, 24);
            this.chkbxXP.TabIndex = 10;
            this.chkbxXP.Text = "Legacy Profiles (XP)";
            this.chkbxXP.UseVisualStyleBackColor = true;
            // 
            // chkbxV2
            // 
            this.chkbxV2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbxV2.AutoSize = true;
            this.chkbxV2.Location = new System.Drawing.Point(637, 183);
            this.chkbxV2.Name = "chkbxV2";
            this.chkbxV2.Size = new System.Drawing.Size(147, 24);
            this.chkbxV2.TabIndex = 11;
            this.chkbxV2.Text = "V2 Profiles (Vista)";
            this.chkbxV2.UseVisualStyleBackColor = true;
            // 
            // chkbxV5
            // 
            this.chkbxV5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbxV5.AutoSize = true;
            this.chkbxV5.Location = new System.Drawing.Point(637, 213);
            this.chkbxV5.Name = "chkbxV5";
            this.chkbxV5.Size = new System.Drawing.Size(333, 24);
            this.chkbxV5.TabIndex = 12;
            this.chkbxV5.Text = "V5 Profiles (7, 8, 8.1, 10 - Vers. 1507 / 1511)";
            this.chkbxV5.UseVisualStyleBackColor = true;
            // 
            // chkbxV6
            // 
            this.chkbxV6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkbxV6.AutoSize = true;
            this.chkbxV6.Location = new System.Drawing.Point(637, 243);
            this.chkbxV6.Name = "chkbxV6";
            this.chkbxV6.Size = new System.Drawing.Size(319, 24);
            this.chkbxV6.TabIndex = 13;
            this.chkbxV6.Text = "V6 Profiles (10 - Vers. 1604 / 1703 / 1709)";
            this.chkbxV6.UseVisualStyleBackColor = true;
            // 
            // btnQueryAll
            // 
            this.btnQueryAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQueryAll.Location = new System.Drawing.Point(503, 377);
            this.btnQueryAll.Name = "btnQueryAll";
            this.btnQueryAll.Size = new System.Drawing.Size(128, 68);
            this.btnQueryAll.TabIndex = 8;
            this.btnQueryAll.Text = "Query profiles";
            this.toolTip_btnQueryAll.SetToolTip(this.btnQueryAll, "UnRoamify will check which profiles from the \"Profiles to be deleted\" list exist " +
        "in the Roaming Profiles Path and adds them to the list box on the right");
            this.btnQueryAll.UseVisualStyleBackColor = true;
            this.btnQueryAll.Click += new System.EventHandler(this.btnQueryAll_Click);
            // 
            // listBxProfiles
            // 
            this.listBxProfiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBxProfiles.FormattingEnabled = true;
            this.listBxProfiles.ItemHeight = 20;
            this.listBxProfiles.Location = new System.Drawing.Point(637, 303);
            this.listBxProfiles.Name = "listBxProfiles";
            this.listBxProfiles.Size = new System.Drawing.Size(319, 284);
            this.listBxProfiles.TabIndex = 18;
            // 
            // radBtnAlphaSort
            // 
            this.radBtnAlphaSort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radBtnAlphaSort.AutoSize = true;
            this.radBtnAlphaSort.Location = new System.Drawing.Point(637, 273);
            this.radBtnAlphaSort.Name = "radBtnAlphaSort";
            this.radBtnAlphaSort.Size = new System.Drawing.Size(154, 24);
            this.radBtnAlphaSort.TabIndex = 16;
            this.radBtnAlphaSort.TabStop = true;
            this.radBtnAlphaSort.Text = "Sort alphabetically";
            this.radBtnAlphaSort.UseVisualStyleBackColor = true;
            this.radBtnAlphaSort.CheckedChanged += new System.EventHandler(this.radBtnAlphaSort_CheckedChanged);
            // 
            // radBtnDontSort
            // 
            this.radBtnDontSort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radBtnDontSort.AutoSize = true;
            this.radBtnDontSort.Location = new System.Drawing.Point(797, 273);
            this.radBtnDontSort.Name = "radBtnDontSort";
            this.radBtnDontSort.Size = new System.Drawing.Size(95, 24);
            this.radBtnDontSort.TabIndex = 17;
            this.radBtnDontSort.TabStop = true;
            this.radBtnDontSort.Text = "Don\'t sort";
            this.radBtnDontSort.UseVisualStyleBackColor = true;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openConfigToolStripMenuItem,
            this.saveConfigToolStripMenuItem,
            this.exportConfigToolStripMenuItem,
            this.importConfigToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openConfigToolStripMenuItem
            // 
            this.openConfigToolStripMenuItem.Name = "openConfigToolStripMenuItem";
            this.openConfigToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.openConfigToolStripMenuItem.Text = "Open Another Config";
            this.openConfigToolStripMenuItem.Click += new System.EventHandler(this.openConfigToolStripMenuItem_Click);
            // 
            // saveConfigToolStripMenuItem
            // 
            this.saveConfigToolStripMenuItem.Name = "saveConfigToolStripMenuItem";
            this.saveConfigToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.saveConfigToolStripMenuItem.Text = "Save Current Config";
            this.saveConfigToolStripMenuItem.Click += new System.EventHandler(this.saveConfigToolStripMenuItem_Click);
            // 
            // exportConfigToolStripMenuItem
            // 
            this.exportConfigToolStripMenuItem.Name = "exportConfigToolStripMenuItem";
            this.exportConfigToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.exportConfigToolStripMenuItem.Text = "Export Config";
            this.exportConfigToolStripMenuItem.Click += new System.EventHandler(this.exportConfigToolStripMenuItem_Click);
            // 
            // importConfigToolStripMenuItem
            // 
            this.importConfigToolStripMenuItem.Name = "importConfigToolStripMenuItem";
            this.importConfigToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.importConfigToolStripMenuItem.Text = "Import Config";
            this.importConfigToolStripMenuItem.Click += new System.EventHandler(this.importConfigToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.specialDeletionToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(971, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip2";
            // 
            // specialDeletionToolStripMenuItem
            // 
            this.specialDeletionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteAllLegacyToolStripMenuItem,
            this.deleteAllV2ToolStripMenuItem,
            this.deleteAllV5ToolStripMenuItem,
            this.deleteAllV6ToolStripMenuItem});
            this.specialDeletionToolStripMenuItem.Name = "specialDeletionToolStripMenuItem";
            this.specialDeletionToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.specialDeletionToolStripMenuItem.Text = "Special Deletion";
            // 
            // deleteAllLegacyToolStripMenuItem
            // 
            this.deleteAllLegacyToolStripMenuItem.Name = "deleteAllLegacyToolStripMenuItem";
            this.deleteAllLegacyToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.deleteAllLegacyToolStripMenuItem.Text = "Delete All Legacy";
            this.deleteAllLegacyToolStripMenuItem.Click += new System.EventHandler(this.deleteAllLegacyToolStripMenuItem_Click);
            // 
            // deleteAllV2ToolStripMenuItem
            // 
            this.deleteAllV2ToolStripMenuItem.Name = "deleteAllV2ToolStripMenuItem";
            this.deleteAllV2ToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.deleteAllV2ToolStripMenuItem.Text = "Delete all .V2";
            this.deleteAllV2ToolStripMenuItem.Click += new System.EventHandler(this.deleteAllV2ToolStripMenuItem_Click);
            // 
            // deleteAllV5ToolStripMenuItem
            // 
            this.deleteAllV5ToolStripMenuItem.Name = "deleteAllV5ToolStripMenuItem";
            this.deleteAllV5ToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.deleteAllV5ToolStripMenuItem.Text = "Delete all .V5";
            this.deleteAllV5ToolStripMenuItem.Click += new System.EventHandler(this.deleteAllV5ToolStripMenuItem_Click);
            // 
            // deleteAllV6ToolStripMenuItem
            // 
            this.deleteAllV6ToolStripMenuItem.Name = "deleteAllV6ToolStripMenuItem";
            this.deleteAllV6ToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.deleteAllV6ToolStripMenuItem.Text = "Delete all .V6";
            this.deleteAllV6ToolStripMenuItem.Click += new System.EventHandler(this.deleteAllV6ToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.instructionsToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // instructionsToolStripMenuItem
            // 
            this.instructionsToolStripMenuItem.Name = "instructionsToolStripMenuItem";
            this.instructionsToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.instructionsToolStripMenuItem.Text = "Instructions";
            this.instructionsToolStripMenuItem.Click += new System.EventHandler(this.instructionsToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // txbxUser
            // 
            this.txbxUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.txbxUser.Font = new System.Drawing.Font("Open Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbxUser.Location = new System.Drawing.Point(0, 24);
            this.txbxUser.Name = "txbxUser";
            this.txbxUser.ReadOnly = true;
            this.txbxUser.Size = new System.Drawing.Size(971, 28);
            this.txbxUser.TabIndex = 19;
            // 
            // btnAutoDelete
            // 
            this.btnAutoDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAutoDelete.Location = new System.Drawing.Point(503, 74);
            this.btnAutoDelete.Name = "btnAutoDelete";
            this.btnAutoDelete.Size = new System.Drawing.Size(128, 48);
            this.btnAutoDelete.TabIndex = 25;
            this.btnAutoDelete.Text = "Start Auto Deleting";
            this.toolTip_btnStart.SetToolTip(this.btnAutoDelete, "Take ownership and control access of the folders, files and subfolders of the pro" +
        "files in the list box and then delete them");
            this.btnAutoDelete.UseVisualStyleBackColor = true;
            this.btnAutoDelete.Click += new System.EventHandler(this.btnAutoDelete_Click);
            // 
            // txbxADAdmin
            // 
            this.txbxADAdmin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxADAdmin.Location = new System.Drawing.Point(12, 94);
            this.txbxADAdmin.Name = "txbxADAdmin";
            this.txbxADAdmin.Size = new System.Drawing.Size(265, 28);
            this.txbxADAdmin.TabIndex = 20;
            // 
            // txbxADAdminPasswd
            // 
            this.txbxADAdminPasswd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxADAdminPasswd.Location = new System.Drawing.Point(283, 94);
            this.txbxADAdminPasswd.Name = "txbxADAdminPasswd";
            this.txbxADAdminPasswd.PasswordChar = '*';
            this.txbxADAdminPasswd.Size = new System.Drawing.Size(214, 28);
            this.txbxADAdminPasswd.TabIndex = 21;
            // 
            // txbxDomain1
            // 
            this.txbxDomain1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txbxDomain1.Location = new System.Drawing.Point(638, 94);
            this.txbxDomain1.Name = "txbxDomain1";
            this.txbxDomain1.Size = new System.Drawing.Size(318, 28);
            this.txbxDomain1.TabIndex = 22;
            // 
            // radBtnDelByProfile
            // 
            this.radBtnDelByProfile.AutoSize = true;
            this.radBtnDelByProfile.Location = new System.Drawing.Point(3, 3);
            this.radBtnDelByProfile.Name = "radBtnDelByProfile";
            this.radBtnDelByProfile.Size = new System.Drawing.Size(141, 24);
            this.radBtnDelByProfile.TabIndex = 26;
            this.radBtnDelByProfile.TabStop = true;
            this.radBtnDelByProfile.Text = "Delete by Profile";
            this.radBtnDelByProfile.UseVisualStyleBackColor = true;
            // 
            // radBtnDelByUser
            // 
            this.radBtnDelByUser.AutoSize = true;
            this.radBtnDelByUser.Location = new System.Drawing.Point(3, 23);
            this.radBtnDelByUser.Name = "radBtnDelByUser";
            this.radBtnDelByUser.Size = new System.Drawing.Size(128, 24);
            this.radBtnDelByUser.TabIndex = 27;
            this.radBtnDelByUser.TabStop = true;
            this.radBtnDelByUser.Text = "Delete by User";
            this.radBtnDelByUser.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.radBtnDelByProfile);
            this.panel1.Controls.Add(this.radBtnDelByUser);
            this.panel1.Location = new System.Drawing.Point(804, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 50);
            this.panel1.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 594);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAutoDelete);
            this.Controls.Add(this.txbxDomain1);
            this.Controls.Add(this.txbxADAdminPasswd);
            this.Controls.Add(this.txbxADAdmin);
            this.Controls.Add(this.txbxUser);
            this.Controls.Add(this.radBtnDontSort);
            this.Controls.Add(this.radBtnAlphaSort);
            this.Controls.Add(this.listBxProfiles);
            this.Controls.Add(this.btnQueryAll);
            this.Controls.Add(this.chkbxV6);
            this.Controls.Add(this.chkbxV5);
            this.Controls.Add(this.chkbxV2);
            this.Controls.Add(this.chkbxXP);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnSavProf);
            this.Controls.Add(this.txbxProfilesInput);
            this.Controls.Add(this.txbxDelProf);
            this.Controls.Add(this.btnDelProf);
            this.Controls.Add(this.btnLogLoc);
            this.Controls.Add(this.txbxLog);
            this.Controls.Add(this.btnSelectRoamingLocation);
            this.Controls.Add(this.txbxRoamLoc);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Open Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimumSize = new System.Drawing.Size(740, 550);
            this.Name = "Form1";
            this.Text = "UnRoamify";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbxRoamLoc;
        private System.Windows.Forms.Button btnSelectRoamingLocation;
        private System.Windows.Forms.TextBox txbxLog;
        private System.Windows.Forms.Button btnLogLoc;
        private System.Windows.Forms.Button btnDelProf;
        private System.Windows.Forms.TextBox txbxDelProf;
        private System.Windows.Forms.TextBox txbxProfilesInput;
        private System.Windows.Forms.Button btnSavProf;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.CheckBox chkbxXP;
        private System.Windows.Forms.CheckBox chkbxV2;
        private System.Windows.Forms.CheckBox chkbxV5;
        private System.Windows.Forms.CheckBox chkbxV6;
        private System.Windows.Forms.ToolTip toolTip_btnSavProf;
        private System.Windows.Forms.Button btnQueryAll;
        private System.Windows.Forms.ListBox listBxProfiles;
        private System.Windows.Forms.RadioButton radBtnAlphaSort;
        private System.Windows.Forms.RadioButton radBtnDontSort;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openConfigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveConfigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportConfigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importConfigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox txbxUser;
        private System.Windows.Forms.ToolTip toolTip_btnLogLoc;
        private System.Windows.Forms.ToolTip toolTip_btnSelectRoamingLocation;
        private System.Windows.Forms.ToolTip toolTip_btnDelProf;
        private System.Windows.Forms.ToolTip toolTip_btnQueryAll;
        private System.Windows.Forms.ToolTip toolTip_btnStart;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instructionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.TextBox txbxADAdminPasswd;
        private System.Windows.Forms.TextBox txbxDomain1;
        private System.Windows.Forms.Button btnAutoDelete;
        private System.Windows.Forms.TextBox txbxADAdmin;
        private System.Windows.Forms.RadioButton radBtnDelByProfile;
        private System.Windows.Forms.RadioButton radBtnDelByUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem specialDeletionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllLegacyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllV2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllV5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllV6ToolStripMenuItem;
    }
}

